package com.example.ztoreme_1

class Categoria {

    var idCategoria : Int = 0
    var nombreCategoria : String = ""

    constructor(nombreCategoria : String){
        this.nombreCategoria = nombreCategoria
    }

    constructor(){ }
}